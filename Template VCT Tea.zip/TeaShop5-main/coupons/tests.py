from django.test import TestCase

# There are no tests in the Coupons app
