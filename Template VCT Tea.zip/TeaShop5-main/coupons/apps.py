from django.apps import AppConfig

# class names the app
class CouponsConfig(AppConfig):
    name = 'coupons'
