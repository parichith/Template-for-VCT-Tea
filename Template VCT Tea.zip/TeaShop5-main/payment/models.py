from django.db import models

# There are no models in the payment app.
