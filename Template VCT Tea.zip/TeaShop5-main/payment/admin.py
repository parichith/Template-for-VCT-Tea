from django.contrib import admin

# There are no models to be registered in the Payment app.
