from django.apps import AppConfig

# The app config for payment 
class PaymentConfig(AppConfig):
    name = 'payment'
