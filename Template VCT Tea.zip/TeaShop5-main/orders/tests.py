from django.test import TestCase

# No tests are present in the Orders app.
