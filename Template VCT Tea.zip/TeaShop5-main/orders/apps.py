from django.apps import AppConfig

# This class creates an order class with a name of an order
class OrdersConfig(AppConfig):
    name = 'orders'
