from django.apps import AppConfig

# This class configurate for the shop app is named 'shop'
class ShopConfig(AppConfig):
    name = 'shop'
